$(function() {
    "use strict";


    $(".peity-line").peity("line", {
        fill: ["transparent"],
        width: "100%",
        height: "100"
    });


});