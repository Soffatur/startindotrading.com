<div class="container-fluid copyright-section">
    <div class="row ">
        <div class="col-lg-12">
            <p class="copyright">&copy; Copyright {{ date('Y') }} by xtream-forex. All Rights Reserved.</p>
        </div>
    </div>
</div>
