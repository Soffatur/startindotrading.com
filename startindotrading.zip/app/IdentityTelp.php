<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdentityTelp extends Model
{
    protected $guarded = [];

    protected $table = 'identity_telp';
}
