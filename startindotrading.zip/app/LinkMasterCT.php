<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LinkMasterCT extends Model
{
    protected $guarded = [];

    protected $table = 'link_master_c_t_s';
}
