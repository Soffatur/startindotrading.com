<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tracker extends Model
{
    protected $guarded = [];

    protected $table = 'trackers';
}
