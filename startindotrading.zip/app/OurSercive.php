<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OurSercive extends Model
{
    protected $guarded = [];

    protected $table = 'our_service';
}
