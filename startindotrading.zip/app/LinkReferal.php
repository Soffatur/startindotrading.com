<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LinkReferal extends Model
{
    protected $guarded = [];

    protected $table = 'link_referals';
}
