<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdentityWebsite extends Model
{
    protected $guarded = [];

    protected $table = 'identity_websites';
}
