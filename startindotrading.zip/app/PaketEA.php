<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaketEA extends Model
{
    protected $guarded = [];

    protected $table = 'paket_e_a_s';
}
