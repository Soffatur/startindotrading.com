<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LinkEA extends Model
{
    protected $guarded = [];

    protected $table = 'link_e_a_s';
}
