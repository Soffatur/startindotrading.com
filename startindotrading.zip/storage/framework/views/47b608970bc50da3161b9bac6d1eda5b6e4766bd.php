<!doctype html>
<html lang="zxx">

<head>
    <!-- All Meta -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="<?php echo e($identitywebsite->meta_description); ?>">
    <meta name="keywords" content="<?php echo e($identitywebsite->meta_keyword); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:title" content="<?php echo e($identitywebsite->og_title); ?>" />
    <meta property="og:image" content="<?php echo e(asset('/storage') . '/' . $identitywebsite->og_image); ?>" />
    <meta property="og:description" content="<?php echo e($identitywebsite->og_description); ?>">
    <meta name="og:site_name" content="<?php echo e($identitywebsite->og_sitename); ?>">
    <!-- page title -->
    <title><?php echo e($identitywebsite->name_website); ?></title>
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('/storage') . '/' . $identitywebsite->favicon); ?>" type="image/x-icon">
    
    <!--All Css here -->
    <!--Bootstrap v3.3.7 css-->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/bootstrap/css/bootstrap.min.css">
    <!-- Fontawesome css -->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/font-awesome.min.css">
    <!-- owl carousel css -->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/owl.theme.default.min.css">
    <!-- magnific popup css -->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/magnific-popup.css">
    <!-- animate css -->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/animate.css">
    <!-- normalize css -->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/normalize.css">
    <!--main style css-->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/main.css">
    <!--Responsive css-->
    <link rel="stylesheet" href="<?php echo e(asset('tamai')); ?>/assets/css/responsive.css">
    <!-- modernizr js -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">
    <!-- Start Preloader Area-->
    <div class="preloader-area">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div><!-- End Preloader Area-->
    <!-- Start header area -->
    <header id="header-area">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(route('landing')); ?>"><img
                        src="<?php echo e(asset('/storage') . '/' . $identitywebsite->logo); ?>"
                        alt="<?php echo e($identitywebsite->name_website); ?>" style="height: 50px"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynavbar">
                    <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span></button>
                <div class="collapse navbar-collapse justify-content-end" id="mynavbar">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a class="page-scroll nav-link" href="#home">Home</a></li>
                        <li class="nav-item"><a class="page-scroll nav-link" href="#about">About</a></li>
                        <li class="nav-item"><a class="page-scroll nav-link" href="#copy-trade">Copy Trades</a></li>
                        <li class="nav-item d-none"><a class="page-scroll nav-link" href="#portfolio">Portfolio</a></li>
                        <li class="nav-item d-none"><a class="page-scroll nav-link" href="#team">Team</a></li>
                        <li class="nav-item"><a class="page-scroll nav-link" href="#layanan-kami">Layanan Kami</a></li>
                        <li class="nav-item d-none"><a class="page-scroll nav-link" href="#blog">Blog</a></li>
                        <li class="nav-item"><a class="page-scroll nav-link" href="#contact">Hubungi Kami</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!--End header area -->
    <!-- Start banner section -->
    <section class="banner" id="home">
        <div class="tamai-overlay"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="welcome-area text-center">
                        <div class="welcome-text">
                            <h2><?php echo e($identitywebsite->title); ?></h2>
                            <h6><?php echo e($identitywebsite->content); ?></h6>
                        </div>
                        <div class="row justify-content-center">
                            <div class="welcome-btn m-1 mt-4">
                                <?php echo $identitywebsite->button; ?>

                            </div>
                            <?php $__currentLoopData = $identityTelp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="welcome-btn m-1 mt-4">
                                    <a href="https://api.whatsapp.com/send/?phone=<?php echo e($row->number); ?>&text=<?php echo e($row->name_number); ?>"
                                        target="_blank" class="tamai-btn"><?php echo e($row->name_number); ?></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End banner section -->
    <!-- Start About-us section -->
    <section class="about-us section-padding" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tamai-header text-center">
                        <h2>About <span>XTREAMFOREX</span></h2>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="about-inifo">
                        
                        <p>XtreamForex adalah Broker ECN dengan Pertumbuhan Tercepat yang dioperasikan oleh Xtream
                            Markets Ltd.
                            Kami terdaftar dan diatur oleh Pulau Marshall. XtreamForex menyediakan layanan perdagangan
                            di Forex,
                            komoditas, indeks, saham, dan cryptocurrency..</p>
                        <p>Dengan kondisi perdagangan terbaik, kami menawarkan kepada Anda variasi akun yang tak
                            tertandingi
                            jenis, platform, dan perangkat yang dapat disesuaikan pelanggan dengan nyaman dan efisien
                            pengalaman perdagangan.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-right">
                        <div class="video-area text-center tamai-video">
                            <a class="video-play" href="https://www.youtube.com/watch?v=1RE1q-2EoAg"><i
                                    class="fa fa-play"></i></a>
                            <h4>Watch video</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About-us section -->
    <!-- Start Gallery -->
    <section class="service section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tamai-header text-center">
                        <h2>Gallery <span>Foto</span></h2>
                    </div>
                </div>
            </div>
            <div class="row slider">
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <img src="<?php echo e(asset('/storage') . '/' . $row->gallery_name); ?>" alt="" width="100%"
                            class="img-thumbnail">
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- End Gallery -->
    <!--Start Features section -->
    <section class="features section-padding" id="layanan-kami">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tamai-header text-center">
                        <h2>Layanan <span>Kami</span></h2>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 no-padding">
                    <div class="features-img">
                        <img src="<?php echo e(asset('tamai')); ?>/assets/img/features.jpg" class="img-fluid" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="features-area">
                        <div id="accordion">
                            <?php $__currentLoopData = $ourService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card f-bottom">
                                    <div class="card-header" id="heading<?php echo e($row['id']); ?>">
                                        <h5 class="mb-0">
                                            <a class="collapsed" data-toggle="collapse" class="text-bold"
                                                data-target="#collapse<?php echo e($row['id']); ?>" aria-expanded="false"
                                                aria-controls="collapse<?php echo e($row['id']); ?>">
                                                <?php echo e($row['our_name_service']); ?>

                                                <i class="fa fa-angle-down"></i>
                                                <i class="fa fa-angle-up"></i>
                                            </a>
                                        </h5>
                                    </div>
                                    <div id="collapse<?php echo e($row['id']); ?>" class="collapse"
                                        aria-labelledby="heading<?php echo e($row['id']); ?>" data-parent="#accordion">
                                        <div class="card-body">
                                            <?php if(!empty($row['detail_our_service'])): ?>
                                                <?php $__currentLoopData = $row['detail_our_service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo $det->description; ?> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Features section -->
    <!-- Start Service section -->
    
    <!-- End Service section -->
    <!-- Start counter section -->
    
    <!-- End counter section -->
    <!-- Start Our-work section -->
    <section class="about-us section-padding" id="copy-trade">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tamai-header text-center">
                        <h2>COPY TRADES WITH <span>XTREAMFOREX</span></h2>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-7" style="padding-right: 70px">
                    <div class="about-inifo">
                        
                        <p>Program Copy Trading XtreamForex menawarkan kesempatan untuk secara otomatis menyalin
                            perdagangan dari trader sukses sehingga Anda tidak perlu menghabiskan banyak waktu untuk
                            mengembangkan strategi Anda sendiri.
                            Bergabunglah dengan program Copy Trading sekarang dan biarkan profesional terpilih bekerja
                            untuk Anda!</p>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="about-right">
                        
                        
                        <div class="video-area text-center tamai-video">
                            <a class="video-play" href="https://www.youtube.com/watch?v=2KzJ1p_eN-A"><i
                                    class="fa fa-play"></i></a>
                            <h4>Watch video</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--End Our-work section -->
    <!-- Start Tamai-video section -->
    
    <!--End Tamai-video section -->
    <!-- Start Pricing section -->
    <section class="pricing section-padding" id="pricing">
        <div class="container">
            
            <div class="row">
                <?php $__currentLoopData = $paketeas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="pricing-table">
                            <div class="pricing-head">
                                <h3><?php echo e($item->name_deposit); ?></h3>
                            </div>
                            <div class="price-tag">
                                <h2> Deposit</h2>
                            </div>
                            <div class="pricing-body">
                                <ul>
                                    <li>
                                        <p class="font-weight-bolder">Low Risk : $<?php echo e($item->low_risk); ?></p>
                                    </li>
                                    <li>
                                        <p class="font-weight-bolder">Medium Risk : $<?php echo e($item->medium_risk); ?></p>
                                    </li>
                                    <li>
                                        <p class="font-weight-bolder">High Risk : $<?php echo e($item->high_risk); ?></p>
                                    </li>
                                    <li style="font-size: 10px; font-weight: bold">Batas Kerugian :
                                        <?php echo e($item->loss_limit); ?>% dari deposit (max$<?php echo e($item->max_deposit); ?>)</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a href="#" class="tamai-btn">Order</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--End Pricing section -->
    <!-- Start Team section -->
    
    <!--End Team section -->
    <!-- Start Testimonial section -->
    <section class="testimonial section-padding" id="testimonial">
        <div class="tamai-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tamai-header overlay-text text-center">
                        <h2>Client <span>Review</span></h2>
                        <p>Beberapa testimoni client kami yang telah kerjasama</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="review-slide owl-carousel">
                        <?php $__currentLoopData = $testimonis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="testimonial-area text-center">
                                <div class="member">
                                    <img src="<?php echo e(asset('/storage') . '/' . $item->photo); ?>" class="img-fluid" alt="">
                                    <h5><?php echo e($item->name); ?></h5>
                                    <span><?php echo e($item->position); ?></span>
                                </div>
                                <div class="review-text">
                                    <p><?php echo e($item->content); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Testimonial section -->
    <!-- Start Tamai-faq section -->
    
    <!--End Tamai-faq section -->
    <!-- Start Subscribe section -->
    
    <!--End Subscribe section-->
    <!-- Start Blog section -->
    
    <!-- End Blog section -->
    <!-- Start Client section -->
    <section class="client section-padding">
        <div class="container">
            
            <div class="row responsive owl-carousel">
                <div class="text-center">
                    <div class="client-img">
                        <a href="#"><img src="<?php echo e(asset('img/ourclients/bca.svg')); ?>" alt="netteler"></a>
                    </div>
                </div>
                <div class="text-center">
                    <div class="client-img">
                        <a href="#"><img src="<?php echo e(asset('img/ourclients/mandiri.svg')); ?>" alt="skrill"></a>
                    </div>
                </div>
                <div class="text-center">
                    <div class="client-img">
                        <a href="#"><img src="<?php echo e(asset('img/ourclients/bni.png')); ?>" alt="visa hover"></a>
                    </div>
                </div>
                <div class="text-center">
                    <div class="client-img">
                        <a href="#"><img src="<?php echo e(asset('img/ourclients/bri.png')); ?>" alt="master card"></a>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Client section -->
    <!-- Start contact section -->
    <section class="contact section-padding" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tamai-header text-center">
                        <h2>Hubungi <span>Kami</span></h2>
                        
                    </div>
                </div>
            </div>
            <div class="row justify-content-center contact-bottom">
                <div class="col-lg-4">
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Address</h4>
                            <h6><?php echo e($identitywebsite->alamat); ?></h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Phone</h4>
                            <h6><?php echo e($identitywebsite->telepon); ?></h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-envelope-o"></i>
                        </div>
                        <div class="contact-details">
                            <h4>Email</h4>
                            <h6><?php echo e($identitywebsite->email); ?></h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row d-none">
                <div class="col-lg-6">
                    <div class="contact-area">
                        <div class="map-area">
                            <div id="map"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="contact-form">
                        <div id="error" class="alert alert-danger" style="display: none">Msg Sending Failed</div>
                        <div id="success" class="alert alert-success" style="display: none">Msg Sending Success</div>
                        <form id="contact-form" method="post"
                            action="https://webtend.net/demo/html/tamai/send_mail.php">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Your Name" name="name" required>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Your Email" name="email" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Subject" name="subject" required>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" rows="5" placeholder="Message" name="message"
                                    required></textarea>
                            </div>
                            <div class="send-btn">
                                <button type="submit" class="tamai-btn" value="submit">send</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End contact section -->
    <!-- Start Footer area -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-xs-12">
                    <div class="footer-text">
                        <?php echo $identitywebsite->footer; ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="footer-social-link">
                        <ul>
                            <li><a href="https://www.facebook.com/<?php echo e($identitywebsite->facebook); ?>"
                                    target="_blank"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/<?php echo e($identitywebsite->twitter); ?>" target="_blank"><i
                                        class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/<?php echo e($identitywebsite->instagram); ?>"
                                    target="_blank"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer><!-- End Footer area -->
    <!--Scroll-up-->
    <a id="scroll-up"><i class="fa fa-angle-up"></i></a>
    <!-- jequery  -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/vendor/jquery-1.12.4.min.js"></script>
    
    <!-- Bootstrap min.js  -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('tamai')); ?>/assets/bootstrap/js/popper.min.js"></script>
    <!-- Owl carousel js  -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/owl.carousel.min.js"></script>
    <!-- isotope min.js  -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/isotope.min.js"></script>
    <!-- imageloaded js-->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- counterup js-->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/jquery.counterup.min.js"></script>
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/waypoints.min.js"></script>
    <!-- magnific-popup js  -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/jquery.magnific-popup.min.js"></script>
    <!-- wow js -->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/wow.min.js"></script>
    <!-- gmaps js -->
    <script src="http://maps.google.com/maps/api/js?key=AIzaSyBOQMDDOsJA0uHTqXTDHUogDJfaTST7hNQ"></script>
    <!--ajax mail-chimp js-->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/jquery.ajaxchimp.min.js"></script>
    <!--main js-->
    <script src="<?php echo e(asset('tamai')); ?>/assets/js/main.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script>
        $('.slider').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 4,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    </script>
</body>

</html>
<?php /**PATH E:\AZATA\startindotrading\resources\views\landing\index.blade.php ENDPATH**/ ?>