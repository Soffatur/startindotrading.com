

<?php $__env->startSection('title', 'Gallery'); ?>

<?php $__env->startSection('body'); ?>
<div class="tables-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 ml-auto mb-2">
                <button class="btn btn-success" data-toggle="modal" data-target="#btnFormTestimoni"><i class="fa fa-plus"></i> Create Gallery Photo</button>
            </div>
            <div class="col-12">
                <div class="accordion table-data">
                    <div class="card rounded-0">
                        <div class="card-header">
                            <h4 class="mb-0" data-toggle="collapse" data-target="#table-one" aria-expanded="true" aria-controls="table-one">
                                <i class="fa pull-right accordion__angle--animated" aria-hidden="true"></i>
                            </h4>
                        </div>
                        <div id="table-one" class="collapse show table-responsive">
                            <table class="table m-b-0">
                                <thead>
                                    <tr>
                                        <th scope="col" width="5%">No</th>
                                        <th scope="col" width="15%">Gallery Name</th>
                                        <th scope="col" width="20%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($row->gallery_name); ?></td>
                                        <td>
                                            <a class='btn btn-warning edittestimoni' href='javascript:void(0)' data-id="<?php echo e($row->id); ?>" data-toggle="modal" data-target="#ubahtestimoni">Edit</a>
                                            <a href="javascript:void(0)" data-id="<?php echo e($row->id); ?>"  class="btn btn-sm btn-danger btnFormHapustestimoni"> Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="btnFormTestimoni" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Gallery</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" id="finserttestimoni">
                    <div class="form-group">
                        <label for="photo">Image</label>
                        <input type="file" class="form-control" name="photo" placeholder="Image" autocomplete="off">
                        <small class="text-danger" id="vc_image"></small>
                    </div>
                    <div class="form-group" id="fprocessinserttestimoni">
                        <button type="submit" class="btn btn-info btn-block" id="testimoniinsertbtn"><i class="fas fa-feather-alt"></i> Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="ubahtestimoni" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Gallery</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" id="fupdatetestimoni">
                    <input type="hidden" name="id_gallery">
                    <div class="form-group">
                        <label for="photo">Image</label>
                        <input type="file" class="form-control" name="photo" placeholder="Image" autocomplete="off">
                        <small class="text-danger" id="vu_image"></small>
                    </div>
                    <div class="form-group" id="fprocessupdatetestimoni">
                        <button type="submit" class="btn btn-info btn-block" id="testimoniupdatebtn"><i class="fas fa-feather-alt"></i> Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AZATA\startindotrading\resources\views\gallery\index.blade.php ENDPATH**/ ?>