<!-- <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png"> -->
<link rel="manifest" href="site.webmanifest">
<link rel="apple-touch-icon" href="icon.png">
<!-- Place favicon.ico in the root directory -->

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('paito/main')); ?>/css/style.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.css">

<style>
    .login-card {
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
</style>
<?php /**PATH E:\AZATA\startindotrading\resources\views\layouts\css.blade.php ENDPATH**/ ?>