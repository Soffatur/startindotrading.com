<div class="container-fluid copyright-section">
    <div class="row ">
        <div class="col-lg-12">
            <p class="copyright">&copy; Copyright <?php echo e(date('Y')); ?> by xtream-forex. All Rights Reserved.</p>
        </div>
    </div>
</div>
<?php /**PATH E:\AZATA\startindotrading\resources\views/layouts/footer.blade.php ENDPATH**/ ?>